export default {
  // COUNTER
  counter: document.getElementById('counter'),
  increment: document.querySelector('[data-increment]'),
  current: document.getElementById('current'),
  decrement: document.querySelector('[data-decrement]'),
  // COUNTER
  // MODULE 7
  // MODULE 7
}
